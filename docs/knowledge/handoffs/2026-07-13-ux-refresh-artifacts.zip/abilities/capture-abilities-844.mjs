import { chromium } from 'file:///C:/Users/nalfeo/.copilot/repos/copilot-worktrees/Crawler/nalfeo-redesigned-couscous/node_modules/playwright/index.mjs';

const url = 'http://127.0.0.1:5299/lab.html?lab=abilities-lab&review=1';
const output =
  'C:/Users/nalfeo/.copilot/session-state/28581642-4ca5-4d5f-9498-e82105f8a3d7/files/visual-review';
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 844, height: 390 } });

await page.goto(url, { waitUntil: 'commit', timeout: 45_000 });
await page.waitForFunction(() => window.__abilitiesProbe?.ready(), undefined, {
  timeout: 45_000,
});
await page.waitForTimeout(750);
await page.screenshot({ path: `${output}/orchestration-delta-hotbar-844x390.png` });

await page.evaluate(() => window.__abilitiesProbe.openLoadout());
await page.waitForFunction(() => window.__abilitiesProbe?.getSnapshot().open === true);
await page.waitForTimeout(300);
await page.screenshot({ path: `${output}/orchestration-delta-loadout-844x390.png` });

await page.evaluate(() => window.__abilitiesProbe.openRewardPicker());
await page.waitForFunction(() => window.__abilitiesProbe?.getRewardPickerSnapshot() !== null);
await page.waitForTimeout(300);
await page.screenshot({ path: `${output}/orchestration-delta-reward-picker-844x390.png` });

console.log(
  JSON.stringify(
    await page.evaluate(() => ({
      uiReady: window.__uiProbe?.ready?.() ?? null,
      reward: window.__abilitiesProbe.getRewardPickerSnapshot(),
    })),
  ),
);
await browser.close();
