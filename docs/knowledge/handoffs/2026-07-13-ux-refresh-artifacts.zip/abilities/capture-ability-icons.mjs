import { chromium } from 'playwright';

const base = 'http://127.0.0.1:5299/lab.html?lab=abilities-lab&review=1';
const output = 'C:/Users/nalfeo/.copilot/session-state/28581642-4ca5-4d5f-9498-e82105f8a3d7/files/visual-review';
const browser = await chromium.launch({ headless: true });

for (const { width, height } of [
  { width: 1280, height: 720 },
  { width: 960, height: 540 },
]) {
  const page = await browser.newPage({ viewport: { width, height } });
  for (let attempt = 0; attempt < 3; attempt += 1) {
    await page.goto(base, { waitUntil: 'commit', timeout: 45_000 });
    try {
      await page.waitForFunction(() => window.__abilitiesProbe?.ready(), undefined, {
        timeout: 45_000,
      });
      break;
    } catch (error) {
      if (attempt === 2) throw error;
    }
  }
  await page.waitForTimeout(750);
  await page.screenshot({ path: `${output}/change-6-icons-hotbar-${width}x${height}.png` });
  await page.evaluate(() => window.__abilitiesProbe.openLoadout());
  await page.waitForFunction(() => window.__abilitiesProbe?.getSnapshot().open === true);
  await page.waitForTimeout(300);
  await page.screenshot({ path: `${output}/change-6-icons-loadout-${width}x${height}.png` });
  await page.close();
}

await browser.close();
