import { chromium } from 'playwright';
import { readFile, writeFile } from 'node:fs/promises';

const [preset, viewportName, widthText, heightText, prefix = 'before'] = process.argv.slice(2);
const width = Number(widthText);
const height = Number(heightText);
const setup = await readFile('scripts/agent/review/setup/hud-encounter.js', 'utf8');
const browser = await chromium.launch({ headless: true });

try {
  const context = await browser.newContext({ viewport: { width, height } });
  const page = await context.newPage();
  await page.goto(`http://127.0.0.1:4178/lab.html?lab=hud-lab&preset=${preset}`, {
    waitUntil: 'commit',
    timeout: 60_000,
  });
  await page.waitForFunction(() => window.__hudProbe?.ready?.(), null, { timeout: 60_000 });
  await page.addScriptTag({ content: setup });
  await page.waitForTimeout(700);
  const data = await page.evaluate(() => ({
    regions: window.__visualReview?.regions ?? [],
    canvas: (() => {
      const rect = document.querySelector('#lab-canvas canvas')?.getBoundingClientRect();
      return rect
        ? { x: rect.x, y: rect.y, width: rect.width, height: rect.height }
        : null;
    })(),
  }));
  const byId = new Map(data.regions.map((region) => [region.id, region.box]));
  const intersects = (a, b) =>
    Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x) > 0 &&
    Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y) > 0;
  const contains = (a, b) =>
    b.x >= a.x - 0.01 &&
    b.y >= a.y - 0.01 &&
    b.x + b.width <= a.x + a.width + 0.01 &&
    b.y + b.height <= a.y + a.height + 0.01;
  const panelIds = ['timer-panel', 'boss-panel', 'announcement-panel', 'quest-panel', 'minimap'].filter(
    (id) => byId.has(id),
  );
  const overlaps = [];
  for (let i = 0; i < panelIds.length; i += 1) {
    for (let j = i + 1; j < panelIds.length; j += 1) {
      if (intersects(byId.get(panelIds[i]), byId.get(panelIds[j]))) {
        overlaps.push(`${panelIds[i]}<>${panelIds[j]}`);
      }
    }
  }
  const overruns = [];
  for (const [textId, panelId] of [
    ['timer-text', 'timer-panel'],
    ['boss-text', 'boss-panel'],
    ['announcement-text', 'announcement-panel'],
  ]) {
    if (byId.has(textId) && byId.has(panelId) && !contains(byId.get(panelId), byId.get(textId))) {
      overruns.push(`${textId}>${panelId}`);
    }
  }
  const screenshotPath = `files/visual-review/${prefix}-${preset}-${viewportName}.png`;
  const geometryPath = `files/visual-review/${prefix}-${preset}-${viewportName}.json`;
  await page.screenshot({ path: screenshotPath });
  await writeFile(
    geometryPath,
    JSON.stringify({ viewport: viewportName, preset, screenshotPath, ...data, overlaps, overruns }, null, 2),
  );
  console.log(
    `${viewportName} ${preset}: overlaps=${overlaps.join(',') || 'none'} overruns=${overruns.join(',') || 'none'} -> ${screenshotPath}`,
  );
  await context.close();
} finally {
  await browser.close();
}
